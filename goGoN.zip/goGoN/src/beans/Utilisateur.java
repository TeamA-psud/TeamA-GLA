package beans;

import java.util.Date;

public class Utilisateur {
    // attributs
    private String   nom;
    private String   prenom;
    private int      age;
    private String   adresse;
    private Date     dateNaiss;
    private String   telephone;

    private String   email;
    private String   sex;
    private String   motPass;
    private String[] prefAlim;
    private String[] moyTrans;

    // geters and setters
    public String getNom() {
        return nom;
    }

    public void setNom( String nom ) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom( String prenom ) {
        this.prenom = prenom;
    }

    public int getAge() {
        return age;
    }

    public void setAge( int age ) {
        this.age = age;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse( String adresse ) {
        this.adresse = adresse;
    }

    public Date getDateNaiss() {
        return dateNaiss;
    }

    public void setDateNaiss( Date dateNaiss ) {
        this.dateNaiss = dateNaiss;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone( String telephone ) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail( String email ) {
        this.email = email;
    }

    public String getSex() {
        return sex;
    }

    public void setSex( String sex ) {
        this.sex = sex;
    }

    public String getMotPass() {
        return motPass;
    }

    public void setMotPass( String motPass ) {
        this.motPass = motPass;
    }

    public String[] getPrefAlim() {
        return prefAlim;
    }

    public void setPrefAlim( String[] prefAlim ) {
        this.prefAlim = prefAlim;
    }

    public String[] getMoyTrans() {
        return moyTrans;
    }

    public void setMoyTrans( String[] moyTrans ) {
        this.moyTrans = moyTrans;
    }

}